# Fontsource Bai Jamjuree

[![npm (scoped)](https://img.shields.io/npm/v/@fontsource/bai-jamjuree?color=brightgreen)](https://www.npmjs.com/package/@fontsource/bai-jamjuree) [![Generic badge](https://img.shields.io/badge/fontsource-passing-brightgreen)](https://github.com/fontsource/fontsource) [![Monthly downloads](https://badgen.net/npm/dm/@fontsource/bai-jamjuree)](https://github.com/fontsource/fontsource) [![Total downloads](https://badgen.net/npm/dt/@fontsource/bai-jamjuree)](https://github.com/fontsource/fontsource) [![GitHub stars](https://img.shields.io/github/stars/fontsource/fontsource.svg?style=social&label=Star)](https://github.com/fontsource/fontsource/stargazers)

The CSS and web font files to easily self-host the “Bai Jamjuree” font. Please visit the main [Fontsource website](https://fontsource.org/fonts/bai-jamjuree) to view more details on this package.

## Quick Installation

Fontsource offers multiple methods to import the CSS, including using a bundler like Vite or using SASS. You can find full documentation [here](https://fontsource.org/docs/getting-started/introduction).

```javascript
npm install @fontsource/bai-jamjuree
```

Within your app entry file or site component, import it in.

```javascript
import "@fontsource/bai-jamjuree"; // Defaults to weight 400
import "@fontsource/bai-jamjuree/400.css"; // Specify weight
import "@fontsource/bai-jamjuree/400-italic.css"; // Specify weight and style
```

Supported variables:
- Weights: `[200,300,400,500,600,700]`
- Styles: `[italic,normal]`
- Subsets: `[latin,latin-ext,thai,vietnamese]`

> Note: `italic` may not be supported by all fonts. To learn more about what weights and styles are supported, please visit the [Fontsource website](https://fontsource.org/fonts/bai-jamjuree).

Finally, you can reference the font name in a CSS stylesheet, CSS Module, or CSS-in-JS.

```css
body {
  font-family: "Bai Jamjuree";
}
```

## Licensing
Always make sure to read the license for each font you use. Most of the fonts in the collection use the SIL Open Font License, v1.1. Some fonts use the Apache 2 license. The Ubuntu fonts use the Ubuntu Font License v1.0.

Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-ExtraLightItalic.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-Light.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-LightItalic.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-Regular.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-Italic.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-Medium.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-MediumItalic.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-SemiBold.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-SemiBoldItalic.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-Bold.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree) BaiJamjuree-BoldItalic.ttf: Copyright 2018 Bai Jamjuree (https://github.com/cadsondemak/Bai-Jamjuree)
[OFL-1.1](https://openfontlicense.org)

## Other Notes
Font version (provided by source): `v13`.

If you have any suggestions or ideas to improve the performance of font loading or expand the existing library, feel free to star and contribute to this repository. You can share your suggestions or ideas by creating an [issue](https://github.com/fontsource/fontsource/issues).